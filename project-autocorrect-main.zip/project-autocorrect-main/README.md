## Summary

This repository represents the CS-4742 (Natural Language Processing) semester project for the group consisting of: Jazwaur A. Spencer F. Nicholas H. and Cassidy S.

Our overall objective is to research varying techniques of autocorrection in a text application. We are exploring these approaches: Previous Context, Levenshtein (Edit) distance, and Keyboard distance. 

## Usage

## License

License for Dataset(s) used

- DailyDialog
    - [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).